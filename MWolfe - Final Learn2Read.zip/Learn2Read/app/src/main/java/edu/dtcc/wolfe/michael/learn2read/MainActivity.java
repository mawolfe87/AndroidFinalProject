package edu.dtcc.wolfe.michael.learn2read;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeechService;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, TextToSpeech.OnInitListener {
    //Declare necessary variables
    //TTS Object
    TextToSpeech tts;
    Button btnWordOne;
    Button btnWordTwo;
    Button btnWordThree;
    Button btnWordFour;
    String question;
    String correct;
    String incorrect;
    TextView scoreDisplay;
    LinearLayout scoreHeader;

    @Override
    protected void onPause() { //Shutdown TTS object
        if(tts != null){
            tts.stop();
            tts.shutdown();
        }
        super.onPause();
    }

    @Override
    public void onInit(int status) { //Set TTS object language
        if(status != TextToSpeech.ERROR){
            tts.setLanguage(Locale.US);
        }
    }

    String answer;
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Create variable-view references
        tts = new TextToSpeech(MainActivity.this, this);
        correct = getResources().getString(R.string.correct_prompt);
        incorrect = getResources().getString(R.string.incorrect_prompt);
        btnWordOne = (Button) findViewById(R.id.btnWordOne);
        btnWordOne.setOnClickListener(this);
        btnWordTwo = (Button) findViewById(R.id.btnWordTwo);
        btnWordTwo.setOnClickListener(this);
        btnWordThree = (Button) findViewById(R.id.btnWordThree);
        btnWordThree.setOnClickListener(this);
        btnWordFour = (Button) findViewById(R.id.btnWordFour);
        btnWordFour.setOnClickListener(this);
        scoreDisplay = (TextView)findViewById(R.id.tvScore);
        scoreHeader = (LinearLayout)findViewById(R.id.scoreHeader);
        scoreDisplay.setText(Integer.toString(score));
        askQuestion();
    }
//-----addStar-----
//    Instantiates a new image view and sets the background resource to a drawable xml file
//    Adds the view to scoreHeader layout
//    Creates new AnimationDrawable from the new image view's background then runs the animation
    private void addStar()
    {
        ImageView star = new ImageView(this);
        star.setBackgroundResource(R.drawable.star_spin);
        scoreHeader.addView(star);
        // Get the background, which has been compiled to an AnimationDrawable object.
        AnimationDrawable frameAnimation = (AnimationDrawable) star.getBackground();
        // Start the animation (looped playback by default).
        frameAnimation.start();
    }

//-----askQuestion-----
//    Randomly selects 4 words and a random correct one of the 4
//    Then asks the user to press the button with the correct word written on it
    private void askQuestion() {

        Random rand = new Random();
        question = getResources().getString(R.string.question_prompt);
        String[] words = getResources().getStringArray(R.array.words);
        int wordOneNum = rand.nextInt(99);
        int wordTwoNum = rand.nextInt(99);
        int wordThreeNum = rand.nextInt(99);
        int wordFourNum = rand.nextInt(99);
        int correctWord = rand.nextInt(4);

        if (correctWord == 0) {
            question += " " + words[wordOneNum];
            answer = words[wordOneNum];
        } else if (correctWord == 1) {
            question += " " + words[wordTwoNum];
            answer = words[wordTwoNum];
        } else if (correctWord == 2) {
            question += " " + words[wordThreeNum];
            answer = words[wordThreeNum];
        } else if (correctWord == 3) {
            question += " " + words[wordFourNum];
            answer = words[wordFourNum];
        }
        btnWordOne.setText(words[wordOneNum]);
        btnWordTwo.setText(words[wordTwoNum]);
        btnWordThree.setText(words[wordThreeNum]);
        btnWordFour.setText(words[wordFourNum]);

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                tts.speak(question, TextToSpeech.QUEUE_ADD, null);
            }
        }, 500);


    }

    @Override
    public void onClick(View v) {
        Button pressed = (Button) v;
        String buttonText = pressed.getText().toString();
        if (buttonText == answer) {
            tts.speak(correct, TextToSpeech.QUEUE_ADD, null);
            score++;
            scoreDisplay.setText(Integer.toString(score));
            btnWordOne.setText("");
            btnWordTwo.setText("");
            btnWordThree.setText("");
            btnWordFour.setText("");
            if(score % 2 == 0){
                addStar();
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    askQuestion();
                }
            }, 1000);

        } else {
            tts.speak(incorrect, TextToSpeech.QUEUE_ADD, null);

        }

    }
}

